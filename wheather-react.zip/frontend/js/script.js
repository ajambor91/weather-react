class Header extends React.Component{
    render(){
        return (
            <h1>Sprawdzenie pogody</h1>
        )
    }
}

class UnitShift extends React.Component{
    render(){
        return(
            <button data-unit={this.props.unit} onClick={this.props.onClick} className="button">{this.props.unit}</button>
        )
    }    
}
class Wheather extends React.Component{


    componentDidUpdate(prevProps){
        if(this.props.location != prevProps.location ){
            this.props.getData();
        }
    }
    componentDidMount(){
        this.props.getData();
    }
    render(){
        return(
            <div id="wheather-container" className="wheather-container {this.props.wheaterType}">
                <ul className="wheather-list">
       
                </ul>
            </div>
        )
    }
}
class Loader extends React.Component{
    render(){
        return(
            <p>Ładowanie</p>
        )
    }
}
class RandomCity extends React.Component{
    render() {
        return (
            <div>
                <button  onClick={this.props.onClick}>Random place</button>
            </div>
        )
    }
}
class App extends React.Component{
    constructor(){
        super();       
        this.Url = 'backend/apiConnect.php?city=';

        this.state = {
            city:'Warsaw',
            country: 'Poland',
            location:'Warsaw, Poland',
            unit: 'c',
            temperature: false,
            description:false,
            loading:false
        }
    }
    getData = () =>{
        this.setState(prevState =>{
            return{
                loading:true
            }
        });
        this.setState(prevState=>{
            fetch(this.Url + this.state.city +'&country='+ this.state.country)
            .then(resp=>resp.json()) 
            .then(resp => {
                this.setState(prevState => {
                    
                    if (resp.status == true){
                        let description = resp.description;
                        let temperature = resp.temperature;
              
                        return {
                            loading:false,
                            temperature:temperature,
                            description:description
                        
                        }}
                    else{
                        return {
                            loading:false,
                            temperature:false,
                            description:false
                        }
                    }});    

            })
            .catch(resp=>{
               this.setState(prevState=>{
                return {
                    loading:false,
                    temperature:false,
                    description:false
                }
               }); 
            });
        })
    }
    selectCity = (e) =>{
        let location = e.target.value;
        let strippedLocation = location.toLowerCase();
        strippedLocation = strippedLocation.replace(/ /g,'');
        strippedLocation = strippedLocation.split(',');
        this.setState( prevState =>{
           
                return{
                    loading:true,
                    city:strippedLocation[0],
                    country:strippedLocation[1],
                    location:location


                }
            });
    };  
    randomCity = () =>{
        this.setState( prevState =>{
            return{
                
            }
        });
    }  
    changeUnit = (e) =>{
        let currentUnit = e.target.dataset.unit.toLowerCase();
        this.setState(prevState=>{
            console.log(currentUnit + ' ' + prevState.unit);
            let temperature = this.state.temperature;
            if(currentUnit == 'c' && prevState.unit == 'f'){
                temperature = ((temperature-32)/1.8).toFixed(0);
            }
            else if(currentUnit == 'f' && prevState.unit == 'c'){
                temperature = ((temperature * 1.8)+32).toFixed(0);
            }
           
            return{
                unit:currentUnit,
                temperature: temperature
            }    
        });
        
      
    }
    render(){
        return(
            <div className="app">
                <UnitShift unit='C'  onClick={this.changeUnit.bind(this)}/>
                <UnitShift unit='F' onClick={this.changeUnit.bind(this)}/>
                <CitySelection location={this.state.location} onChange={this.selectCity.bind()}/> 
                <Wheather getData={this.getData.bind(this)} location={this.state.location}/>
                {this.state.loading ? (
                        <Loader />
                    ):(    
                        <WheaterDescription wheatherDescription="Temperatura" temperature={this.state.temperature} />
              
                    )}    
            </div>
        )
    }
}
class WheaterDescription extends React.Component{
    render(){
        return(
            <div>{this.props.wheatherDescription} {this.props.temperature}</div>
        )
    }
}
class CitySelection extends React.Component{

    render(){
        return (
            <div>
                <input value={this.props.location} type="text" onChange={this.props.onChange}></input>
            </div>
        )
    }
}
ReactDOM.render(
    <App/>,
    document.getElementById('app')
  );